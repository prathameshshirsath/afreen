import {ToastrService} from '../../../../node_modules/ngx-toastr';
import {BsModalService, BsModalRef} from 'ngx-bootstrap/modal';
import { Component } from '@angular/core';
import { EmployeeService } from 'src/app/shared/services/employees.service';
import { AddEditEmployeeComponent } from './add-edit-employee/add-edit-employee.component';
import { DeleteModalComponent } from 'src/app/shared/components/delete-modal/delete-modal.component';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss']
})

export class EmployeesComponent {

  public totalCount: number = 0;
  public data: any[] = [];
  public addEditEmployeeModal!: BsModalRef;
  public removeDeleteEmployeeModal!: BsModalRef;

  constructor (private employeeService : EmployeeService, 
    private toastrService: ToastrService,
    private modalService: BsModalService){}

  ngOnInit() {
    this.loadEmployees();
  }

  private loadEmployees (): void {
    this.employeeService.getEmployees().subscribe((response: any) => {
      this.data = response;
      this.totalCount = response.length;
    })
  }

  public openAddEditEmployeeModal (employee: any = null): void {
    this.addEditEmployeeModal = this.modalService.show(AddEditEmployeeComponent,{
      initialState: {employee: employee}, class: '',
      ignoreBackdropClick: true
    });
    this.addEditEmployeeModal.content.close.subscribe(() => {
      this.addEditEmployeeModal.hide();
      this.loadEmployees();
    });
  }

  public opendeleteEmployeeModal (employee: any) : void {
     this.removeDeleteEmployeeModal = this.modalService.show(DeleteModalComponent, { 
      class: '',
      ignoreBackdropClick: true
    });
    this.removeDeleteEmployeeModal.content.close.subscribe(() => {
      this.removeDeleteEmployeeModal.hide();
      
    });
    this.removeDeleteEmployeeModal.content.delete.subscribe(() => {
      this.employeeService.deleteEmployee(employee.id).subscribe((response: any) => {
        this.toastrService.success('Employee deleted successfully', 'Success');
      }, (error: any) => {
        this.toastrService.error('Error deleting employee', 'Error');
      });
      this.removeDeleteEmployeeModal.hide();
      this.loadEmployees();
    });
  }

}




