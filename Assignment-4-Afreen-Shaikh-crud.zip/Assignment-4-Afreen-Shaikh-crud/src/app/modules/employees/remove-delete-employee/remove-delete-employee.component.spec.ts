import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveDeleteEmployeeComponent } from './remove-delete-employee.component';

describe('RemoveDeleteEmployeeComponent', () => {
  let component: RemoveDeleteEmployeeComponent;
  let fixture: ComponentFixture<RemoveDeleteEmployeeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RemoveDeleteEmployeeComponent]
    });
    fixture = TestBed.createComponent(RemoveDeleteEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
