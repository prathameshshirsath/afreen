import { Component, EventEmitter, Input, Output } from '@angular/core';
import { EmployeeService } from 'src/app/shared/services/employees.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-remove-delete-employee',
  templateUrl: './remove-delete-employee.component.html',
  styleUrls: ['./remove-delete-employee.component.scss']
})
export class RemoveDeleteEmployeeComponent {
  @Input() employee: any;
  @Output() close = new EventEmitter();
  @Output() delete = new EventEmitter();

  constructor(private employeeService: EmployeeService,
    private toastrService: ToastrService) { }

    public onClose(): void {
      this.close.emit();
    }

    public save(): void {
        this.deleteEmployee(this.employee);
    }

    private deleteEmployee(payload: any): void {
      this.employeeService.deleteEmployee(payload).subscribe((response: any) => {
        this.toastrService.success('Employee deleted successfully', 'Success');
        this.onClose();
      }, (error: any) => {
        this.toastrService.error('Error deleting employee', 'Error');
      });
    }
}
