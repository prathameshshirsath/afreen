import { Component } from '@angular/core';

@Component({
  selector: 'app-pagenotfound',
  template: '<h2 class="mt-5 pt-5 text-center">Page not found</h2>',
})
export class PageNotFoundComponent {
 
}
