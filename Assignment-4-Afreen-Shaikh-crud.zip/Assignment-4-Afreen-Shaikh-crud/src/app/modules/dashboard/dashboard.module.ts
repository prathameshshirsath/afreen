import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ToastrModule } from 'ngx-toastr';
import {ModalModule} from 'ngx-bootstrap/modal';
import { BannerComponent } from '../banner/banner.component';
import { EmployeesComponent } from '../employees/employees.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { AddEditEmployeeComponent } from '../employees/add-edit-employee/add-edit-employee.component';
import { RemoveDeleteEmployeeComponent } from '../employees/remove-delete-employee/remove-delete-employee.component';
import { DeleteModalComponent } from 'src/app/shared/components/delete-modal/delete-modal.component';
import { DashboardComponent } from './dashboard.component';
import { CommonModule } from '@angular/common';
import { HelloComponent } from './hello/hello.component';
import { AuthGuard } from 'src/app/shared/helper/auth.guard';

const dashboardRoutes: Routes = [{
  path:'dashboard' ,
  component: DashboardComponent,
  children: [
  { path: 'home', component: BannerComponent,canActivate:[AuthGuard] },
  { path: 'employees', component: EmployeesComponent,canActivate:[AuthGuard]},
  { path: '**', component: PageNotFoundComponent,canActivate:[AuthGuard]}
],canActivate:[AuthGuard]
}];


@NgModule({
  declarations: [
   
    EmployeesComponent,
    AddEditEmployeeComponent,
    RemoveDeleteEmployeeComponent,
    DeleteModalComponent,
    HelloComponent,
  ],
  imports: [
    RouterModule.forChild(dashboardRoutes),
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxDatatableModule,
    ModalModule.forRoot(),
    ToastrModule.forRoot(),
    CommonModule
  ],
  exports: [RouterModule]
})
export class DashboardModule { }
