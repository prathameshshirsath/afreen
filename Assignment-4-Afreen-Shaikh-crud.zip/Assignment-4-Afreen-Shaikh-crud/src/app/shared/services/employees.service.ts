import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(private http : HttpClient) { }

  public getEmployees() : any {
    return this.http.get(`http://localhost:8000/employees`);
  }

  public addEmployee (employee : any) : any {
    return this.http.post(`http://localhost:8000/employees`,employee);
  }

  public updateEmployee (employee : any) : any {
    return this.http.put(`http://localhost:8000/employees/${employee.id}`,employee);
  }

  public deleteEmployee (employeeId : any) : any {
    return this.http.delete(`http://localhost:8000/employees/${employeeId}`);
  }
}