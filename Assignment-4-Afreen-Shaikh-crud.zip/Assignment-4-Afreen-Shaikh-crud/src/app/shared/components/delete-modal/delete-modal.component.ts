import { Component, EventEmitter, Input, Output } from '@angular/core';
import { EmployeeService } from '../../services/employees.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrls: ['./delete-modal.component.scss']
})
export class DeleteModalComponent {

  @Output() close = new EventEmitter();
  @Output() delete = new EventEmitter();

  // constructor(private employeeService: EmployeeService,
  //   private toastrService: ToastrService) { }

    public onClose(): void {
      this.close.emit();
    }

    public onDelete () :void{
      this.delete.emit();
    }
    // public save(): void {
    //     this.deleteEmployee(this.employee);
    // }

    // private deleteEmployee(payload: any): void {
    //   this.employeeService.deleteEmployee(payload).subscribe((response: any) => {
    //     this.toastrService.success('Employee deleted successfully', 'Success');
    //     this.onClose();
    //   }, (error: any) => {
    //     this.toastrService.error('Error deleting employee', 'Error');
    //   });
    // }
}
